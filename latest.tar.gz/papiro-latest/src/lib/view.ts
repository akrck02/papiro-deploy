export type viewHandler = (params : string[], container : HTMLElement) => Promise<void> 

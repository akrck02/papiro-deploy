
# Papiro
---

Papiro is a minimal wiki to publish documents with markdown and HTML.

![cat](./cat.jpg)

![cat](https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Fa-z-animals.com%2Fmedia%2F2023%2F04%2Fshutterstock_716019169.jpg&f=1&nofb=1&ipt=69458a5572ab6435b79b31dcd6fe032de3ede9fcf2caf304c6687d3fd0f4a2e2)
# Getting started 🚀
---
Getting started with papiro is very easy, right now there are 3 ways to set it up.

- [Install papiro locally (recommended only for development or testing)](./installation/local-testing)
- [Deploy as a github page](./installation/github-pages)
- [Ejecute as a docker repository](./installation/docker)
